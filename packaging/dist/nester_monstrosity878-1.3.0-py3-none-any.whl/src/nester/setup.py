from distutils.core import setup

setup( 
	name = 'nester', 
	version = '1.3.0', 
	py_modules = ['nester'],
	author = 'ObscureIT',
	author_email = 'akif.khan1704@gmail.com',
	url = 'https://github.com/obscureIT/headfirstPythonPractice',
	description = 'A simple printer of nested lists',
)